//
//  AchillesTests.swift
//  AchillesTests
//
//  Created by Blind Takes on 3/29/25.
//

import Testing
@testable import Achilles

struct AchillesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
